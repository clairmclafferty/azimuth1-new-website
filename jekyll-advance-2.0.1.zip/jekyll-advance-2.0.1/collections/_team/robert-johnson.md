---
title: "Robert Johnson"
date: 2018-12-20T13:44:30+10:00
weight: 2
description: "Senior web designer and UX designer."
thumbnail: "/assets/images/team/robert-johnson.jpg"
image: "/assets/images/team/robert-johnson.jpg"
jobtitle: "Web Designer"
links:
  - url: "https://www.linkedin.com"
    label: LinkedIn
    icon: "fab fa-linkedin"
  - url: "https://github.com"
    label: Github
    icon: "fab fa-github"
---
