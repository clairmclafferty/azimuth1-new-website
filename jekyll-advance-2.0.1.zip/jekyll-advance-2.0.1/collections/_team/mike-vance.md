---
title: "Mike Vance"
date: 2018-12-20T13:44:30+10:00
weight: 3
description: "Lead creative director for branding and design."
thumbnail: "/assets/images/team/mike-vance.jpg"
image: "/assets/images/team/mike-vance.jpg"
jobtitle: "Art Director"
links:
  - url: "https://www.linkedin.com"
    label: LinkedIn
    icon: "fab fa-linkedin"
  - url: "https://dribbble.com"
    label: Dribbble
    icon: "fab fa-dribbble"
---
