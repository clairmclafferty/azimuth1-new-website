---
title: "Sage Kirk"
date: 2018-12-20T13:44:30+10:00
weight: 1
description: "Sage founded the agency in 2015 and runs day to day operations of the studio."
thumbnail: "/assets/images/team/sage-kirk.jpg"
image: "/assets/images/team/sage-kirk.jpg"
jobtitle: "Founder/Director"
links:
  - url: "https://www.linkedin.com"
    label: LinkedIn
    icon: "fab fa-linkedin"
---
