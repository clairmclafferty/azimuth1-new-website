---
layout: blog
title: Blog
description: "The latest news and opinions"
permalink: "/blog/"
header_transparent: false
pagination:
  enabled: true

hero:
  enabled: false
  heading: "Blog"
  sub_heading: ""
  text_color: "#FFFFFF"
  background_color: ""
  background_gradient: true
  background_image: false
  background_image_blend_mode: false
  fullscreen_mobile: false
  fullscreen_desktop: false
  buttons:
    enabled: false
    list:
      - text: "Contact Us"
        url: "/contact"
        external: false
        fa_icon: false
        size: large
        outline: true
        style: "light"
---
