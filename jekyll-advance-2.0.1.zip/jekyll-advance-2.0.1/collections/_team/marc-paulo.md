---
title: "Marc Paulo"
date: 2018-12-20T13:44:30+10:00
weight: 4
description: "Certified Google Analytics and Google Ad's marketing specialist."
thumbnail: "https://source.unsplash.com/sibVwORYqs0/300x300"
image: "https://source.unsplash.com/sibVwORYqs0/300x300"
jobtitle: "SEO Specialist"
links:
  - url: "https://www.linkedin.com"
    label: LinkedIn
    icon: "fab fa-linkedin"
  - url: "#"
    label: Google +
    icon: "fab fa-google-plus-g"
  - url: "https://www.medium.com"
    label: Medium
    icon: "fab fa-medium"
---
